import React, { useState, useCallback } from 'react';
import { Upload, Settings, Layout, LogOut, Image, Video, Link as LinkIcon } from 'lucide-react';
import { useDropzone } from 'react-dropzone';
import { motion } from 'framer-motion';
import useContent from '../hooks/useContent';

interface AdminPanelProps {
  onLogout: () => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ onLogout }) => {
  const { content, addContent, updateContentLayout } = useContent();
  const [activeTab, setActiveTab] = useState('upload');
  const [newContent, setNewContent] = useState({
    type: 'image' as 'image' | 'video',
    title: '',
    description: '',
    url: '',
    link: ''
  });
  const [uploadProgress, setUploadProgress] = useState(0);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      // Simulate file upload progress
      let progress = 0;
      const interval = setInterval(() => {
        progress += 10;
        setUploadProgress(progress);
        if (progress >= 100) {
          clearInterval(interval);
          // Simulate URL creation
          const url = URL.createObjectURL(file);
          setNewContent(prev => ({
            ...prev,
            url,
            type: file.type.startsWith('video/') ? 'video' : 'image'
          }));
          setTimeout(() => setUploadProgress(0), 1000);
        }
      }, 200);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.png', '.jpg', '.jpeg', '.gif'],
      'video/*': ['.mp4', '.webm']
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addContent(newContent);
    setNewContent({
      type: 'image',
      title: '',
      description: '',
      url: '',
      link: ''
    });
  };

  return (
    <div className="min-h-screen bg-[#0a0118] text-white">
      <nav className="fixed w-full z-50 bg-black/30 backdrop-blur-lg border-b border-purple-500/20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <span className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-600 text-transparent bg-clip-text">
              Aelvander Admin
            </span>
            <div className="flex items-center space-x-6">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setActiveTab('upload')}
                className={`flex items-center space-x-2 ${
                  activeTab === 'upload' ? 'text-purple-400' : 'text-gray-400'
                }`}
              >
                <Upload className="w-5 h-5" />
                <span>Upload</span>
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setActiveTab('layout')}
                className={`flex items-center space-x-2 ${
                  activeTab === 'layout' ? 'text-purple-400' : 'text-gray-400'
                }`}
              >
                <Layout className="w-5 h-5" />
                <span>Layout</span>
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setActiveTab('settings')}
                className={`flex items-center space-x-2 ${
                  activeTab === 'settings' ? 'text-purple-400' : 'text-gray-400'
                }`}
              >
                <Settings className="w-5 h-5" />
                <span>Settings</span>
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={onLogout}
                className="flex items-center space-x-2 text-red-400"
              >
                <LogOut className="w-5 h-5" />
                <span>Logout</span>
              </motion.button>
            </div>
          </div>
        </div>
      </nav>

      <div className="pt-24 px-4 max-w-7xl mx-auto">
        {activeTab === 'upload' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-[#1a0533] rounded-lg p-6 border border-purple-500/30"
          >
            <h2 className="text-2xl font-bold mb-6">Upload New Content</h2>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div
                {...getRootProps()}
                className={`border-2 border-dashed ${
                  isDragActive ? 'border-purple-400' : 'border-purple-500/30'
                } rounded-lg p-8 text-center cursor-pointer transition-colors`}
              >
                <input {...getInputProps()} />
                <div className="flex flex-col items-center space-y-4">
                  {newContent.url ? (
                    newContent.type === 'image' ? (
                      <img src={newContent.url} alt="Preview" className="max-h-48 object-contain" />
                    ) : (
                      <video src={newContent.url} className="max-h-48" controls />
                    )
                  ) : (
                    <>
                      <Upload className="w-12 h-12 text-purple-400" />
                      <p className="text-purple-300">
                        Drag & drop your files here, or click to select files
                      </p>
                    </>
                  )}
                </div>
              </div>

              {uploadProgress > 0 && (
                <div className="w-full bg-[#2a0855] rounded-full h-2">
                  <div
                    className="bg-purple-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${uploadProgress}%` }}
                  />
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Content Type</label>
                  <select
                    value={newContent.type}
                    onChange={(e) => setNewContent({ ...newContent, type: e.target.value as 'image' | 'video' })}
                    className="w-full bg-[#2a0855] border border-purple-500/30 rounded px-4 py-2 text-white focus:outline-none focus:border-purple-400"
                  >
                    <option value="image">Image</option>
                    <option value="video">Video</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Title</label>
                  <input
                    type="text"
                    value={newContent.title}
                    onChange={(e) => setNewContent({ ...newContent, title: e.target.value })}
                    className="w-full bg-[#2a0855] border border-purple-500/30 rounded px-4 py-2 text-white focus:outline-none focus:border-purple-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Description</label>
                <textarea
                  value={newContent.description}
                  onChange={(e) => setNewContent({ ...newContent, description: e.target.value })}
                  className="w-full bg-[#2a0855] border border-purple-500/30 rounded px-4 py-2 text-white focus:outline-none focus:border-purple-400"
                  rows={3}
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">External Link (Optional)</label>
                <div className="relative">
                  <input
                    type="text"
                    value={newContent.link}
                    onChange={(e) => setNewContent({ ...newContent, link: e.target.value })}
                    className="w-full bg-[#2a0855] border border-purple-500/30 rounded px-4 py-2 pl-10 text-white focus:outline-none focus:border-purple-400"
                  />
                  <LinkIcon className="absolute left-3 top-2.5 w-5 h-5 text-purple-400" />
                </div>
              </div>

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                type="submit"
                className="w-full bg-purple-600 hover:bg-purple-500 rounded px-4 py-2 transition-colors"
              >
                Upload Content
              </motion.button>
            </form>
          </motion.div>
        )}

        {activeTab === 'layout' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-[#1a0533] rounded-lg p-6 border border-purple-500/30"
          >
            <h2 className="text-2xl font-bold mb-6">Layout Settings</h2>
            <div className="grid gap-6">
              {content.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-center space-x-4 bg-[#2a0855] p-4 rounded-lg"
                >
                  {item.type === 'image' ? (
                    <Image className="w-6 h-6 text-purple-400" />
                  ) : (
                    <Video className="w-6 h-6 text-purple-400" />
                  )}
                  <span className="flex-1">{item.title}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {activeTab === 'settings' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-[#1a0533] rounded-lg p-6 border border-purple-500/30"
          >
            <h2 className="text-2xl font-bold mb-6">General Settings</h2>
            {/* Add settings options here */}
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default AdminPanel;