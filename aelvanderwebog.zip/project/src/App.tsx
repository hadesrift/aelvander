import React, { useState, useEffect } from 'react';
import { Shield, Youtube, Instagram, Upload, Settings, Layout, LogOut } from 'lucide-react';
import AdminPanel from './components/AdminPanel';
import ContentGrid from './components/ContentGrid';
import Hero from './components/Hero';

function App() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === 'admin@vsk') {
      setIsAdmin(true);
      setShowAdminLogin(false);
      setError('');
    } else {
      setError('Invalid password');
    }
  };

  if (isAdmin) {
    return <AdminPanel onLogout={() => setIsAdmin(false)} />;
  }

  return (
    <div className="min-h-screen bg-[#0a0118] text-white">
      {/* Navigation */}
      <nav className="fixed w-full z-50 bg-black/30 backdrop-blur-lg border-b border-purple-500/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <span className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-600 text-transparent bg-clip-text">
                Aelvander
              </span>
            </div>
            <div className="flex items-center space-x-4">
              <a
                href="https://www.youtube.com/@Aelvander"
                target="_blank"
                rel="noopener noreferrer"
                className="text-purple-400 hover:text-purple-300 transition-colors"
              >
                <Youtube className="w-6 h-6" />
              </a>
              <a
                href="https://www.instagram.com/ig.aelvander/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-purple-400 hover:text-purple-300 transition-colors"
              >
                <Instagram className="w-6 h-6" />
              </a>
              <button
                onClick={() => setShowAdminLogin(true)}
                className="text-purple-400 hover:text-purple-300 transition-colors"
              >
                <Shield className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main>
        <Hero />
        <ContentGrid />
      </main>

      {/* Admin Login Modal */}
      {showAdminLogin && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-[#1a0533] p-8 rounded-lg shadow-2xl border border-purple-500/30 w-full max-w-md">
            <h2 className="text-2xl font-bold mb-4 text-purple-400">Admin Login</h2>
            <form onSubmit={handleAdminLogin}>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter password"
                className="w-full bg-[#2a0855] border border-purple-500/30 rounded px-4 py-2 mb-4 text-white placeholder-purple-300/50 focus:outline-none focus:border-purple-400"
              />
              {error && <p className="text-red-400 mb-4">{error}</p>}
              <div className="flex justify-end space-x-4">
                <button
                  type="button"
                  onClick={() => setShowAdminLogin(false)}
                  className="px-4 py-2 text-purple-400 hover:text-purple-300 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-500 rounded transition-colors"
                >
                  Login
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;