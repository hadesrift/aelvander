import { useState, useEffect } from 'react';

interface ContentItem {
  type: 'image' | 'video';
  title: string;
  description: string;
  url: string;
  link?: string;
}

const useContent = () => {
  const [content, setContent] = useState<ContentItem[]>(() => {
    const savedContent = localStorage.getItem('content');
    return savedContent ? JSON.parse(savedContent) : [
      {
        type: 'image',
        title: 'Welcome to Aelvander GFX',
        description: 'Creating epic gaming content and stunning visual experiences',
        url: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-1.2.1&auto=format&fit=crop&w=2850&q=80',
        link: 'https://www.youtube.com/@Aelvander'
      }
    ];
  });

  useEffect(() => {
    localStorage.setItem('content', JSON.stringify(content));
  }, [content]);

  const addContent = (newContent: ContentItem) => {
    setContent([...content, newContent]);
  };

  const updateContentLayout = (newLayout: ContentItem[]) => {
    setContent(newLayout);
  };

  return {
    content,
    addContent,
    updateContentLayout
  };
};

export default useContent;