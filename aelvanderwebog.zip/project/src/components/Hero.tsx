import React from 'react';

const Hero = () => {
  return (
    <div className="relative h-screen flex items-center justify-center overflow-hidden">
      {/* Background Video */}
      <video
        autoPlay
        loop
        muted
        className="absolute w-full h-full object-cover"
        style={{ filter: 'brightness(0.4)' }}
      >
        <source
          src="https://cdn.pixabay.com/vimeo/147535490/abstract-5165.mp4?width=1280&hash=f443eb90a3c57c0e5eae19e10f3f1df5c5c69629"
          type="video/mp4"
        />
      </video>

      {/* Animated Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-b from-purple-900/20 to-black/50" />
      <div className="absolute inset-0 bg-[url('https://assets.codepen.io/13471/sparkles.gif')] opacity-10" />

      {/* Content */}
      <div className="relative z-10 text-center">
        <div className="relative">
          <h1 className="text-7xl md:text-9xl font-bold mb-6 animate-glow bg-gradient-to-r from-purple-400 via-pink-500 to-purple-600 text-transparent bg-clip-text">
            Aelvander
          </h1>
          <div className="absolute -inset-2 bg-gradient-to-r from-purple-600 to-pink-600 blur opacity-30 animate-pulse"></div>
        </div>
        <p className="text-xl md:text-3xl text-purple-200 max-w-3xl mx-auto px-4 animate-float">
          Crafting Epic Gaming Experiences & Digital Art
        </p>
        
        {/* Call to Action Buttons */}
        <div className="mt-8 flex justify-center gap-4">
          <a
            href="https://www.youtube.com/@Aelvander"
            target="_blank"
            rel="noopener noreferrer"
            className="px-6 py-3 bg-purple-600 hover:bg-purple-500 rounded-full transition-all duration-300 transform hover:scale-105 hover:shadow-[0_0_15px_rgba(147,51,234,0.5)] group"
          >
            <span className="group-hover:animate-pulse">Watch My Content</span>
          </a>
          <a
            href="https://www.instagram.com/ig.aelvander/"
            target="_blank"
            rel="noopener noreferrer"
            className="px-6 py-3 border-2 border-purple-500 hover:border-purple-400 rounded-full transition-all duration-300 transform hover:scale-105 hover:shadow-[0_0_15px_rgba(147,51,234,0.3)] group"
          >
            <span className="group-hover:animate-pulse">Follow Me</span>
          </a>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-purple-400 rounded-full flex justify-center">
          <div className="w-2 h-2 bg-purple-400 rounded-full mt-2 animate-scroll"></div>
        </div>
      </div>
    </div>
  );
};

export default Hero;